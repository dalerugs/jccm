<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="box box-default">
  <div class="box-header with-border">
    <h3 class="box-title">My Network Menu</h3>
  </div>
  <div class="box-body">
    <div class="container-fluid">
      <div class="col-md-12">
    			<ul class="admin-menu">
    				<li>
    					<a href="<?php echo e(route('myNetworkMembers')); ?>"><i class="fa fa-users fa-3x"></i><br />Manage Members</a>
    				</li>
    				<li>
    					<a href="<?php echo e(route('myNetworkRequests')); ?>"><i class="fa fa-check-square-o fa-3x"></i><br />Manage Requests</a>
    				</li>
    			</ul>
        </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>


</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>