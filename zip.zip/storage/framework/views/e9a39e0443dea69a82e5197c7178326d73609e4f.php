<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="box box-default">
  <div class="box-header with-border">
    <h3 class="box-title">Files Data</h3>
  </div>
  <div class="box-body">
    <div class="table-responsive">
      <table id="dataTable" style="margin-top:50px" class="table table-hover table-bordered">
        <thead>
          <tr>
            <th>NAME</th>
            <th>DESCRIPTION</th>
            <th width="5%"></th>
          </tr>
        </thead>
        <tbody id="tableBody"></tbody>
      </table>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>

    $( document ).ready(function() {
      $("#loader").show();
      $.ajax({
           url: "<?php echo e(route('readFiles')); ?>",
           success:function(data) {
             $("#loader").hide();
             var html = "";
             $.each( data, function( key, file ) {
                var filepath = "<?php echo e(asset('files_upload')); ?>/"+file.filename;
                html +=
                "<tr>" +
                  "<td>"+file.name+"</td>" +
                  "<td>"+file.description+"</td>" +
                  "<td>" +
                  "<a href='"+filepath+"' download='"+file.name+"' target='_blank' class='btn btn-primary btn-block'>Download</a>" +
                  "</td>" +
                "</tr>";
                });
                $("#tableBody").html(html);
                $('#dataTable').DataTable();
           }
       });
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>