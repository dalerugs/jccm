<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="box box-default">
  <div class="box-header with-border">
    <h3 class="box-title">Admin Menu</h3>
  </div>
  <div class="box-body">
    <div class="container-fluid">
      <div class="col-md-12">
    			<ul class="admin-menu">
    				<li>
    					<a href="<?php echo e(route('manageMembers')); ?>"><i class="fa fa-users fa-3x"></i><br />Manage Members</a>
    				</li>
    				<li>
              <span style="position:absolute;margin-left:-12px" class="label label-danger notificationCount"></span>
    					<a class="notification " href="<?php echo e(route('manageRequests')); ?>"><i class="notification fa fa-check-square-o fa-3x"></i><br />
                Manage Requests <br />
              </a>

    				</li>
    				<li>
    					<a href="<?php echo e(route('manageBatch')); ?>"><i class="fa fa-certificate fa-3x"></i><br />Manage Batch</a>
    				</li>
    				<li>
    					<a href="<?php echo e(route('manageFiles')); ?>"><i class="fa fa-files-o fa-3x"></i><br />Manage Files</a>
    				</li>
    				<li>
    					<a href="<?php echo e(route('manageUsers')); ?>"><i class="fa fa-id-card-o fa-3x"></i><br />Manage Users</a>
    				</li>
    			</ul>
        </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>